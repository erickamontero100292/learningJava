package com.hashcode;

import com.hashcode.model.Student;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Student alex1 = new Student(1, "Alex");
        Student alex2 = new Student(1, "Alex");
        Student alex3 = alex2;
        System.out.println("alex1 hashcode = " + alex1.hashCode());
        System.out.println("alex2 hashcode = " + alex2.hashCode());
        System.out.println("Checking equality between alex1 and alex2 = " + alex1.equals(alex2));
        System.out.println("Checking equality between alex2 and alex3 = " + alex2.equals(alex3));
    }
}
